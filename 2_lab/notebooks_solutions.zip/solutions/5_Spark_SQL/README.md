# Spark Aufgaben in Jupyter Notebooks
Öffne für diese Aufgaben über das Dashboard das Jupyter Notebooks im Ordner Exercise.<br>
Folge die Anleitung im Notebook.

>Folgene Webseiten und Dokumentationen können dabei helfen. <br>
>https://sparkbyexamples.com/pyspark-tutorial/ <br>
>https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/index.html